/**
 */
package de.ubt.ai1.supermod.example.bootstrap.superstrap;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Visibility Forest</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see de.ubt.ai1.supermod.example.bootstrap.superstrap.SuperstrapPackage#getVisibilityForest()
 * @model
 * @generated
 */
public interface VisibilityForest extends EObject {
} // VisibilityForest
