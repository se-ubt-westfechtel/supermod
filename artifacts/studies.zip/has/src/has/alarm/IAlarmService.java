package has.alarm;

/**
 * 
 * @generated
 */
public interface IAlarmService {

}