package has.alarm;

/**
 * 
 * @generated
 */
public class PoliceInformation {

}