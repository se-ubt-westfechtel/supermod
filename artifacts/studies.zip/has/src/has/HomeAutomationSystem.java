package has;

/**
 * 
 * @generated
 */
public class HomeAutomationSystem {

}