package has.doorLock;

/**
 * 
 * @generated
 */
public interface IDoorLock {

}