package has.doorLock;

/**
 * 
 * @generated
 */
public class PassiveLock {

}