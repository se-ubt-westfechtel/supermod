package has.heating;

/**
 * 
 * @generated
 */
public class Manual {

}