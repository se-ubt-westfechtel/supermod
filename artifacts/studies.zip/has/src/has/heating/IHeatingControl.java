package has.heating;

/**
 * 
 * @generated
 */
public interface IHeatingControl {

}