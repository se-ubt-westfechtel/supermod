package has.identification;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * 
 * @generated
 */
public class IdentificationMechanism {

	/**
	 * * @generated
	 */
	private boolean loggedIn;

	/**
	 * * @opposite has::has::identification::IdentificationMechanism.imechanism
	 * * @generated
	 */
	private IMechanism imechanism;

	/**
	 * * @generated
	 */
	private String identifySignature;

	/**
	 * 
	 * getter for attribute loggedIn : boolean
	 * 
	 * @accessor loggedIn
	 * @generated
	 */
	private boolean isLoggedIn() {
		return this.loggedIn;
	}

	/**
	 * 
	 * setter for attribute loggedIn : boolean
	 * 
	 * @accessor loggedIn
	 * @generated
	 */
	private void setLoggedIn(boolean value) {
		this.loggedIn = value;
	}

	/**
	 * @generated
	 */
	public IMechanism getImechanism() {
		return this.imechanism;
	}

	/**
	 * @generated
	 */
	public void setImechanism(IMechanism newValue) {
		this.imechanism = newValue;
	}

	/**
	 * 
	 * getter for attribute identifySignature : String
	 * 
	 * @accessor identifySignature
	 * @generated
	 */
	private String getIdentifySignature() {
		return this.identifySignature;
	}

	/**
	 * 
	 * setter for attribute identifySignature : String
	 * 
	 * @accessor identifySignature
	 * @generated
	 */
	private void setIdentifySignature(String value) {
		this.identifySignature = value;
	}

	/**
	 * 
	 * @generated NOT
	 */
	private boolean identify() {

		// Start of user code
		// has::has::identification::IdentificationMechanism::identify
		
		List<IMechanism> mechs = new LinkedList<>();
		mechs.add(new Keypad());
		mechs.add(new MagneticCard());
		mechs.add(new FingerprintScanner());
		mechs.add(new Biometric());
		for (int i = 0; i < mechs.size(); i++) {
			System.out.println("" + i + " - " + mechs.get(i).getClass().getSimpleName());
		}
		Scanner s = new Scanner(System.in);
		int mech = s.nextInt();
		IMechanism mechanism = mechs.get(mech);
		return mechanism.checkIdentification(getIdentifySignature());
		// End of user code
	}

	/**
	 * 
	 * @generated
	 */
	public boolean logIn() {

		// Start of user code
		// has::has::identification::IdentificationMechanism::logIn
		// TODO should be implemented
		return false;
		// End of user code
	}

	/**
	 * 
	 * @generated
	 */
	public boolean logOut() {

		// Start of user code
		// has::has::identification::IdentificationMechanism::logOut
		// TODO should be implemented
		return false;
		// End of user code
	}

}