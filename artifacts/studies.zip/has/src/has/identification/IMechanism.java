package has.identification;

/**
 * 
 * @generated
 */
public interface IMechanism {

	/**
	 * 
	 * @generated
	 */
	public boolean checkIdentification(String identifySignature);

}