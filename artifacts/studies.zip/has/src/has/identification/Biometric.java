package has.identification;

/**
 * 
 * @generated
 */
public class Biometric implements IMechanism {

	@Override
	/**
	 * 
	 * @generated
	 */
	public boolean checkIdentification(String identifySignature) {

		// Start of user code
		// has::has::identification::IMechanism::checkIdentification
		// TODO should be implemented
		return false;
		// End of user code
	}

}
