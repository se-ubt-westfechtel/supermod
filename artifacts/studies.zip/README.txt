The Eclipse project contents provided in this archive contain the raw data of the evaluation of SuperMod, submitted to Software and Systems Modeling.

The folders graph, has and superstrap represent SuperMod workspaces. Local repositories are stored in the .supermod folders of every workspace.

Many of the analyses reported on in the article can be reproduced by text-based searches in the model instances of the repositories. For instance, to count the number of versioned elements that carry a visibility, search for occurrences of the string "visibility".

To open the SuperMod projects in Eclipse, please proceed as follows:
- we recommend to start with a clean Eclipse Oxygen Modeling installation
- Help -> Install new Software. Here, install all plug-ins (except for SuperMod to FAMILE Export) from the Eclipse update site: http://btn1x4.inf.uni-bayreuth.de/supermod/update
- The Graph case study has been developed using SuperMod's collaborative versioning strategy. To enable push and pull from a remote repository, it is required to install SuperMod's server-side application, which is available as a Tomcat 8 servlet here: http://btn1x4.inf.uni-bayreuth.de/supermod/webapp/supermod-server.war
- The Graph and HAS case studies depend on the UML 2.0 metamodel (which is included in Eclipse Modeling) and on the Valkyrie editing tool. The latter can be installed from the following update site: http://btn1x4.inf.uni-bayreuth.de/valkyrie/update
- The SuperStrap case study requires in addition the Bootstrapping metamodel and editor to be installed in the target Eclipse platform. The dependencies are contained in this archive as three Eclipse projects: de.ubt.ai1.supermod.example.bootstrap.* . Load them into a fresh Eclipse workspace and start a new Eclipse application from here. In the new runtime, the SuperStrap editor is then available. Alternatively, you can use the reflective EMF model editor.
- After having imported the projects, SuperMod commands are available under the Team submenu. For example, the feature models of all case studies can be accessed via Team -> Edit Variability Model

For further questions, contact Felix Schwaegerl <felix.schwaegerl@uni-bayreuth.de>.